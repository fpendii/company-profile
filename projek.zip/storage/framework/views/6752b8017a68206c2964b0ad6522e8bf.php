<?php $__env->startSection('title', 'Tentang Perusahaan'); ?>

<?php $__env->startSection('content'); ?>
    <section id="inner-headline">
        <div class="container">
            <div class="row">
                <div class="span4">
                    <div class="inner-heading">
                        <h2 style="font-size: 40px">Tentang Perusahaan</h2>
                    </div>
                </div>
                <div class="span8">
                    <ul class="breadcrumb">
                        <li><a href="/beranda"><i class="icon-home"></i></a><i class="icon-angle-right"></i></li>
                        <li><a href="/tentang_perusahaan">Tentang Perusahaan</a><i class="icon-angle-right"></i></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section id="content">
        <div class="container">

            <div class="row mb-4">
                <!-- Kolom Visi -->
                <div class="col-md-6 mb-4 d-flex justify-content-center">
                    <div class="card shadow-sm border-0 rounded">
                        <div class="card-body text-center">
                            <h2 class="card-title text-primary"><strong>Visi</strong></h2>
                            <?php echo $dataUsaha->visi; ?>

                            
                        </div>
                    </div>
                </div>

                <!-- Kolom Misi -->
                <div class="col-md-6 mb-4 d-flex justify-content-center">
                    <div class="card shadow-sm border-0 rounded">
                        <div class="card-body text-center">
                            <h2 class="card-title text-primary"><strong>Misi</strong></h2>
                            <?php echo $dataUsaha->misi; ?>

                            

                        </div>
                    </div>
                </div>


            </div>

            
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('component.template_free_user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BTS\Projek\Ratna_Company\resources\views/free_user/tentang_perusahaan/tentang_perusahaan.blade.php ENDPATH**/ ?>