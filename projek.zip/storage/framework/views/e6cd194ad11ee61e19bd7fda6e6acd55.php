<h2>Kritik dan Saran Baru</h2>
<p><strong>Nama:</strong> <?php echo e($name); ?></p>
<p><strong>Email:</strong> <?php echo e($email); ?></p>
<p><strong>Subjek:</strong> <?php echo e($subject); ?></p>
<p><strong>Pesan:</strong></p>
<p><?php echo e($userMessage); ?></p>
<?php /**PATH D:\BTS\Projek\Ratna_Company\resources\views/emails/kritik_saran.blade.php ENDPATH**/ ?>