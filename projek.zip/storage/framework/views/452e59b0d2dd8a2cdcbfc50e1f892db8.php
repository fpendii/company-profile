<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>
    <section id="inner-headline">
        <div class="container">
            <div class="row">
                <div class="span4">
                    <div class="inner-heading">
                        <h2>Berita</h2>
                    </div>
                </div>
                <div class="span8">
                    <ul class="breadcrumb">
                        <li><a href="/beranda"><i class="icon-home"></i></a><i class="icon-angle-right"></i></li>
                        <li><a href="/berita">berita</a><i class="icon-angle-right"></i></li>
                        <li>Baca Selengkapnya</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section id="content">
        <div class="container">
            <div class="row">
                <div class="">
                        <article>
                            <div class="row">
                                <div class="">
                                    <div class="post-slider">
                                        <div class="post-heading">
                                            <h3><a href="/berita/detail/<?php echo e($dataBerita->id); ?>"><?php echo e($dataBerita->judul); ?></a></h3>
                                        </div>
                                        <!-- start flexslider -->
                                        <div class="flexslider">
                                            <ul class="slides">
                                                <li>
                                                    <img src="<?php echo e(asset('storage/' . $dataBerita->gambar)); ?>" alt="" />
                                                </li>

                                            </ul>
                                        </div>
                                        <!-- end flexslider -->
                                    </div>
                                    <p>
                                        <?php echo e($dataBerita->konten); ?>

                                    </p>
                                    <div class="bottom-article">
                                        <ul class="meta-post">
                                            <li><i class="icon-calendar"></i><a href="#">
                                                    <?php echo e($dataBerita->tanggal_publish); ?></a></li>
                                        </ul>
                                        <a href="/berita/detail/<?php echo e($dataBerita->id); ?>" class="pull-right">Baca selengkapnya <i
                                                class="icon-angle-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </article>


                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('component.template_free_user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BTS\Projek\Ratna_Company\resources\views/free_user/berita/detail.blade.php ENDPATH**/ ?>