<?php $__env->startSection('title', 'Percetakan'); ?>

<?php $__env->startSection('content'); ?>
<section id="inner-headline">
    <div class="container">
        <div class="row">
            <div class="span4">
                <div class="inner-heading">
                    <h2 style="font-size: 40px">Layanan</h2>
                </div>
            </div>
            <div class="span8">
                <ul class="breadcrumb">
                    <li><a href="/beranda"><i class="icon-home"></i></a> <i class="icon-angle-right"></i></li>
                    <li><a href="/layanan">Layanan</a> <i class="icon-angle-right"></i></li>
                    <li>Bimbingan Mahasiswa</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<section id="content">
    <div class="container">
        <div class="row">
            <div class="span12">
                <ul class="portfolio-categ">
                    <li class="<?php echo e(Request::is('layanan') ? 'active' : ''); ?>"><a href="/layanan">Bimbingan Mahasiswa</a></li>
                    <li class="<?php echo e(Request::is('layanan/bimbingan-umum') ? 'active' : ''); ?>"><a href="/layanan/bimbingan-umum">Bimbingan Umum</a></li>
                    <li class="<?php echo e(Request::is('layanan/artikel-ilmiah') ? 'active' : ''); ?>"><a href="/layanan/artikel-ilmiah">Artikel Ilmiah</a></li>
                    <li class="<?php echo e(Request::is('layanan/olah-data') ? 'active' : ''); ?>"><a href="/layanan/olah-data">Olah Data</a></li>
                    <li class="<?php echo e(Request::is('layanan/percetakan') ? 'active' : ''); ?>"><a href="/layanan/percetakan">Percetakan</a></li>
                </ul>
                <div class="clearfix"></div>

                <div class="row">
                    <section id="projects">
                        <article>
                            <!-- Kiri -->
                            <div class="span6">
                                <div class="post-slider">
                                    <div class="post-heading">
                                        <h3><a href="layanan"><?php echo e($layananPercetakan->nama_layanan); ?></a></h3>
                                    </div>
                                    <div class="flexslider">
                                        <ul class="slides">
                                            <li>
                                                <img src="/template-free-user/img/bimbel-mahasiswa.jpeg"
                                                    alt="Bimbingan Mahasiswa" />
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="bottom-article">
                                        <?php echo e($layananPercetakan->penjelasan); ?>

                                        
                                    </div>
                                </div>
                            </div>

                            <!-- Kanan -->
                            <div class="span6">
                                <div class="post-heading">
                                    <h3>Kategori <?php echo e($layananPercetakan->nama_layanan); ?></h3>
                                </div>

                                <?php $__currentLoopData = $layananPercetakan->kategoriLayanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card shadow-sm p-3 mb-4 rounded" style="background-color: #f0f8ff;">
                                        <h4 class="text-primary"><i class="icon-book"></i>
                                            <?php echo e($kategori->nama_kategori); ?></h4>
                                        <p><?php echo e($kategori->penjelasan); ?></p>
                                        <h5>Jurusan:</h5>
                                        <ul class="tags">
                                            <?php $__currentLoopData = $kategori->jurusanKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategoriJurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="btn btn-small btn-info"><?php echo e($kategoriJurusan->jurusan->nama_jurusan); ?>

                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <div class="bottom-article">
                                    <a href="/kontak" class="btn btn-primary mt-3">Hubungi Kami untuk Layanan <i
                                            class="icon-angle-right"></i></a>
                                </div>
                            </div>
                        </article>
                    </section>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('component.template_free_user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BTS\Projek\Ratna_Company\resources\views/free_user/layanan/layanan_percetakan.blade.php ENDPATH**/ ?>