<?php $__env->startSection('title', 'Data Berita'); ?>

<?php
    $page = 'Pengaturan Berita';
?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('component.alert.alert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="container mt-4">

        <div class="row">
            <div class="col-12">


                <div class="span6">
                    <h4>Data Berita</h4>
                    <div class="row mb-4 text-end">
                        <div class="col-12">
                            <a href="<?php echo e(url('admin/berita/tambah')); ?>" class="btn btn-primary">Tambah Berita</a>
                        </div>
                    </div>
                    <table class="table table-hover text-center">
                        <thead>
                            <tr>
                                <th class="col-1">
                                    No
                                </th>
                                <th>
                                    Judul
                                </th>
                                <th>
                                    Tanggal Publish
                                </th>
                                <th class="col-2">
                                    Aksi
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $no = 1;
                            ?>
                            <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($no++); ?>

                                </td>
                                <td>
                                    <?php echo e($berita->judul); ?>

                                </td>
                                <td>
                                    <?php echo e($berita->tanggal_publish); ?>

                                </td>
                                <td>
                                    <a href="<?php echo e(url('admin/berita/edit', $berita->id)); ?>"
                                        class="btn btn-warning btn-sm">Edit</a>
                                    <form action="<?php echo e(url('admin/berita/delete', $berita->id)); ?>" method="POST"
                                        style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm"
                                            onclick="return confirm('Apakah Anda yakin ingin menghapus berita ini?')">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>

                
                <?php echo e($beritas->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('component.template_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BTS\Projek\Ratna_Company\resources\views/admin/berita/berita.blade.php ENDPATH**/ ?>