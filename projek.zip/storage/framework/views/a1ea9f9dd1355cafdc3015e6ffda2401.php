<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>
    <section id="inner-headline">
        <div class="container">
            <div class="row">
                <div class="span4">
                    <div class="inner-heading">
                        <h2>Berita</h2>
                    </div>
                </div>
                <div class="span8">
                    <ul class="breadcrumb">
                        <li><a href="/beranda"><i class="icon-home"></i></a><i class="icon-angle-right"></i></li>
                        <li><a href="/berita">berita</a><i class="icon-angle-right"></i></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section id="content">
        <div class="container">
            <div class="row">
                <div class="span4">
                    <aside class="left-sidebar">
                        <div class="widget">
                            <form class="form-search">
                                <input placeholder="Ketik untuk mencari" type="text" class="input-medium search-query">
                                <button type="submit" class="btn btn-square btn-theme">Cari</button>
                            </form>
                        </div>
                        
                        <div class="widget">
                            <h5 class="widgetheading">Berita Terbaru</h5>
                            <ul class="recent">
                                <?php $__currentLoopData = $beritaTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <img src="<?php echo e(asset('storage/' . $item->gambar)); ?>" alt="" />
                                        <h6><a href="#"><?php echo e($item->judul); ?></a></h6>
                                        <p>
                                            <?php echo e(\Illuminate\Support\Str::limit($item->konten, 30, '...')); ?>

                                        </p>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </ul>
                        </div>
                        
                    </aside>
                </div>
                <div class="span8">
                    <?php $__currentLoopData = $dataBerita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article>
                            <div class="row">
                                <div class="span8">
                                    <div class="post-slider">
                                        <div class="post-heading">
                                            <h3><a href="/berita/detail/<?php echo e($item->id); ?>"><?php echo e($item->judul); ?></a></h3>
                                        </div>
                                        <!-- start flexslider -->
                                        <div class="flexslider">
                                            <ul class="slides">
                                                <li>
                                                    <img src="<?php echo e(asset('storage/' . $item->gambar)); ?>" alt="" />
                                                </li>

                                            </ul>
                                        </div>
                                        <!-- end flexslider -->
                                    </div>
                                    <p>
                                        <?php echo e($item->konten); ?>

                                    </p>
                                    <div class="bottom-article">
                                        <ul class="meta-post">
                                            <li><i class="icon-calendar"></i><a href="#">
                                                    <?php echo e($item->tanggal_publish); ?></a></li>
                                        </ul>
                                        <a href="/berita/detail/<?php echo e($item->id); ?>" class="pull-right">Baca selengkapnya <i
                                                class="icon-angle-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- Pagination -->
                    <div class="pagination">
                        <?php echo e($dataBerita->links()); ?>

                    </div>
                    
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('component.template_free_user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BTS\Projek\Ratna_Company\resources\views/free_user/berita/berita.blade.php ENDPATH**/ ?>