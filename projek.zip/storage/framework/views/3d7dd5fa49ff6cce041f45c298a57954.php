<?php $__env->startSection('title', 'Pengaturan'); ?>

<?php
    $page = 'Pengaturan Data Usaha';
?>

<?php $__env->startSection('content'); ?>

    <!-- CSS -->
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <!-- JS -->
    <script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>

    <?php echo $__env->make('component.alert.alert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="card mb-2">
        <div class="card-body">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <a class="nav-link <?php echo e(Request::is('admin/pengaturan') ? 'active' : ''); ?>" id="home-tab"
                        href="<?php echo e(url('/admin/pengaturan')); ?>" role="tab" aria-controls="home"
                        aria-selected="true"><i class="fa-solid fa-print"></i> Data Usaha</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link <?php echo e(Request::is('admin/pengaturan/layanan') ? 'active' : ''); ?>" id="home-tab"
                        href="<?php echo e(url('admin/pengaturan/layanan')); ?>" role="tab" aria-controls="home"
                        aria-selected="true"><i class="fa-solid fa-book"></i> Layanan </a>
                </li>
            </ul>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header pb-0">
            <h6><?php echo e(Str::of($page)->replace('-', ' ')->title()); ?></h6>
        </div>
        <div class="card-body">

            <!-- Form -->
            <form action="<?php echo e(url('admin/pengaturan/simpan')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <!-- Bagian Tambah Order -->
                <div id="order-fields" style="display: block;">
                    <div class="mb-3">
                        <label for="nama_usaha" class="form-label">Nama Usaha</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['nama_usaha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_usaha"
                            name="nama_usaha" value="<?php echo e(old('nama_usaha', $setting->nama_usaha ?? '')); ?>" required>
                        <?php $__errorArgs = ['nama_usaha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Input lainnya -->
                <div class="mb-3">
                    <label for="slogan" class="form-label">Slogan</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['slogan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="slogan"
                        name="slogan" value="<?php echo e(old('slogan', $setting->slogan ?? '')); ?>" required>
                    <?php $__errorArgs = ['slogan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Input lainnya -->
                <div class="mb-3">
                    <label for="tentang_usaha" class="form-label">Tentang Usaha</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['tentang_usaha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tentang_usaha"
                        name="tentang_usaha" value="<?php echo e(old('tentang_usaha', $setting->tentang_usaha ?? '')); ?>" required>
                    <?php $__errorArgs = ['tentang_usaha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Input lainnya -->
                <div class="mb-3">
                    <label for="alamat" class="form-label">Alamat</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alamat"
                        name="alamat" value="<?php echo e(old('alamat', $setting->alamat ?? '')); ?>" required>
                    <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Input lainnya -->
                <div class="mb-3">
                    <label for="nomer_telepon" class="form-label">Nomer Telepon</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['nomer_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nomer_telepon"
                        name="nomer_telepon" value="<?php echo e(old('nomer_telepon', $setting->nomer_telepon ?? '')); ?>" required>
                    <?php $__errorArgs = ['nomer_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Input lainnya -->
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email"
                        name="email" value="<?php echo e(old('email', $setting->email ?? '')); ?>" required>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Quill Editor untuk Penjelasan Usaha -->
                <div class="mb-3">
                    <label for="penjelasan_usaha" class="form-label">Penjelasan Usaha</label>
                    <div id="editor-penjelasan_usaha" style="height: 150px;"></div>
                    <input type="hidden" name="penjelasan_usaha" id="penjelasan_usaha" value="<?php echo e(old('penjelasan_usaha', $setting->penjelasan_usaha ?? '')); ?>" required>
                    <?php $__errorArgs = ['penjelasan_usaha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Quill Editor untuk Visi -->
                <div class="mb-3">
                    <label for="visi" class="form-label">Visi</label>
                    <div id="editor-visi" style="height: 150px;"></div>
                    <input type="hidden" name="visi" id="visi" value="<?php echo e(old('visi', $setting->visi ?? '')); ?>">
                    <?php $__errorArgs = ['visi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Quill Editor untuk Misi -->
                <div class="mb-3">
                    <label for="misi" class="form-label">Misi</label>
                    <div id="editor-misi" style="height: 150px;"></div>
                    <input type="hidden" name="misi" id="misi" value="<?php echo e(old('misi', $setting->misi ?? '')); ?>">
                    <?php $__errorArgs = ['misi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Tombol Simpan -->
                <div class="d-flex justify-content-between">
                    <a href="<?php echo e(url('admin/pengaturan')); ?>" class="btn btn-secondary">
                       Batal
                    </a>
                    <button type="submit" class="btn btn-primary">
                        <i class="fa fa-save"></i> Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Quill -->
    <script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>

    <script>
        var quillVisi = new Quill('#editor-visi', {
            theme: 'snow'
        });
        var quillMisi = new Quill('#editor-misi', {
            theme: 'snow'
        });
        var quillPenjelasanUsaha = new Quill('#editor-penjelasan_usaha', {
            theme: 'snow'
        });

        // Prefill data lama dari hidden input
        quillVisi.root.innerHTML = `<?php echo old('visi', $setting->visi ?? ''); ?>`;
        quillMisi.root.innerHTML = `<?php echo old('misi', $setting->misi ?? ''); ?>`;
        quillPenjelasanUsaha.root.innerHTML = `<?php echo old('penjelasan_usaha', $setting->penjelasan_usaha ?? ''); ?>`;

        // Ambil data saat submit
        document.querySelector('form').onsubmit = function() {
            document.querySelector('#visi').value = quillVisi.root.innerHTML;
            document.querySelector('#misi').value = quillMisi.root.innerHTML;
            document.querySelector('#penjelasan_usaha').value = quillPenjelasanUsaha.root.innerHTML;
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('component.template_admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BTS\Projek\Ratna_Company\resources\views/admin/pengaturan/pengaturan.blade.php ENDPATH**/ ?>