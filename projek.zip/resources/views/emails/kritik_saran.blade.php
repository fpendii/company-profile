<h2>Kritik dan Saran Baru</h2>
<p><strong>Nama:</strong> {{ $name }}</p>
<p><strong>Email:</strong> {{ $email }}</p>
<p><strong>Subjek:</strong> {{ $subject }}</p>
<p><strong>Pesan:</strong></p>
<p>{{ $userMessage }}</p>
